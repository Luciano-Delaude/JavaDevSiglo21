package exceptions;
public class LibroInexistenteException extends Exception {
    public LibroInexistenteException(String mensaje) {
        super(mensaje);
    }
}
